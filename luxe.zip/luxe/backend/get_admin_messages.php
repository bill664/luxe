<?php
require_once __DIR__.'/db.php'; require_once __DIR__.'/helpers.php'; session_start();
if (empty($_SESSION['user_id'])) { json_err('Login required'); }
$uid = $_SESSION['user_id'];
$pdo->prepare("UPDATE admin_messages SET user_read_at=NOW() WHERE user_id=? AND is_admin_reply=1 AND user_read_at IS NULL")->execute([$uid]);
$st=$pdo->prepare("SELECT * FROM admin_messages WHERE user_id=? ORDER BY created_at ASC"); $st->execute([$uid]);
$rows=$st->fetchAll(PDO::FETCH_ASSOC);
json_ok(['messages'=>$rows]);

<?php
function json_ok($arr){ header('Content-Type: application/json'); echo json_encode(array_merge(['success'=>true],$arr)); exit; }
function json_err($msg){ http_response_code(400); header('Content-Type: application/json'); echo json_encode(['success'=>false,'error'=>$msg]); exit; }
function random_code($len=6){ return str_pad(strval(random_int(0, 10**$len-1)), $len, '0', STR_PAD_LEFT); }
function send_mail($to,$subject,$body){
    // Basic PHP mail(); replace with better mailer on production
    $headers = "From: ".MAIL_FROM_NAME." <".MAIL_FROM.">\r\nContent-Type: text/plain; charset=UTF-8";
    @mail($to,$subject,$body,$headers);
}
?>
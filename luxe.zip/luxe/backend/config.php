<?php
// EDIT THESE
define('DB_HOST','localhost');
define('DB_NAME','luxe');
define('DB_USER','root');
define('DB_PASS','');
define('BASE_URL','/'); // e.g., '/luxemarket/' if in subfolder
// Email settings
define('MAIL_FROM','no-reply@yourdomain.com');
define('MAIL_FROM_NAME','LuxeMarket');
// Paystack
define('PAYSTACK_SECRET','sk_test_xxx');
define('PAYSTACK_PUBLIC','pk_test_xxx');
define('PAYSTACK_PLAN','PLAN_CODE_OPTIONAL'); // if you use plans
?>
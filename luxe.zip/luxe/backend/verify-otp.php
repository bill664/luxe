<?php
session_start();
require_once __DIR__.'/db.php';
require_once __DIR__.'/helpers.php';

$email = $_SESSION['pending_email'] ?? '';
$role  = $_SESSION['pending_role'] ?? 'buyer';

if(!$email){
    die("Session expired. Please register again.");
}

// Verify OTP
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['otp'])){
    $otp = trim($_POST['otp'] ?? '');

    $stmt = $pdo->prepare("SELECT id,otp_code,otp_expires FROM users WHERE email=?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if($user && $user['otp_code'] === $otp && strtotime($user['otp_expires']) > time()){
        // OTP valid -> clear otp fields + reset resend counter and set email_verified
        $pdo->prepare("UPDATE users SET otp_code=NULL, otp_expires=NULL, otp_resend_count=0, otp_last_resend=NULL, email_verified=1 WHERE email=?")
            ->execute([$email]);

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $role;

        unset($_SESSION['pending_email'], $_SESSION['pending_role']);

        $base = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
        if($role === 'seller'){
            header("Location: $base/seller-dashboard.php");
        } else {
            header("Location: $base/browse.php");
        }
        exit;
    } else {
        $error = "Invalid or expired OTP.";
    }
}

// Handle resend with limit
if(isset($_GET['resend'])){
    $stmt = $pdo->prepare("SELECT otp_resend_count, otp_last_resend FROM users WHERE email=?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    $now = time();
    $lastResend = $user['otp_last_resend'] ? strtotime($user['otp_last_resend']) : 0;

    if($user['otp_resend_count'] >= 3 && ($now - $lastResend) < 3600){
        $error = "You have reached the maximum of 3 resends per hour. Please try again later.";
    } else {
        if(($now - $lastResend) > 3600){
            $user['otp_resend_count'] = 0;
        }
        $code = str_pad((string)random_int(0,999999), 6, '0', STR_PAD_LEFT);
        $exp = date('Y-m-d H:i:s', $now+15*60);
        $pdo->prepare("UPDATE users SET otp_code=?, otp_expires=?, otp_resend_count=?, otp_last_resend=? WHERE email=?")
            ->execute([$code, $exp, $user['otp_resend_count']+1, date('Y-m-d H:i:s',$now), $email]);

        send_mail($email, 'Verify your email', 'Your new OTP is: '.$code);
        $success = "A new OTP has been sent to your email.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Verify OTP</title>
    <link rel="stylesheet" href="luxe-style.css">
    <style>
        button[disabled] { background: #ccc; cursor: not-allowed; }
    </style>
</head>
<body>
    <h2>Enter the OTP sent to your email</h2>

    <?php if(!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
    <?php if(!empty($success)) echo "<p style='color:green;'>$success</p>"; ?>

    <form method="post">
        <input type="text" name="otp" placeholder="Enter OTP" required>
        <button type="submit">Verify</button>
    </form>

    <br>

    <!-- Resend button (disabled initially) -->
    <button id="resendBtn" disabled onclick="window.location.href='?resend=1'">
        Resend OTP
    </button>

    <p id="timer">Please wait 30 seconds before resending...</p>

    <script>
        let countdown = 30;
        let timer = document.getElementById("timer");
        let resendBtn = document.getElementById("resendBtn");

        let interval = setInterval(() => {
            countdown--;
            timer.innerText = "Please wait " + countdown + " seconds before resending...";

            if(countdown <= 0){
                clearInterval(interval);
                resendBtn.disabled = false;
                timer.innerText = "You can resend OTP now.";
            }
        }, 1000);
    </script>
</body>
</html>
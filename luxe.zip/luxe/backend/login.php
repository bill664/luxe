<?php
require_once __DIR__.'/db.php';
require_once __DIR__.'/helpers.php';
session_start();

$email = trim($_POST['email'] ?? '');
$pass  = $_POST['password'] ?? '';
$redirect = $_POST['redirect'] ?? ($_GET['redirect'] ?? '');

if ($email==='admin' && $pass==='admin123') {
  $_SESSION['user_id']=0; $_SESSION['role']='admin';
  $base = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
  json_ok(['message'=>'Admin login','redirect'=> "$base/admin-dashboard.php"]);
}

$stmt=$pdo->prepare("SELECT id,password,role,status,email_verified FROM users WHERE email=?");
$stmt->execute([$email]);
$u=$stmt->fetch();

if(!$u || !password_verify($pass,$u['password'])) json_err('Invalid credentials');
if($u['status']!=='active') json_err('Account is banned');
if((int)$u['email_verified']!==1) json_err('Please verify your email to continue.');

$_SESSION['user_id']=$u['id'];
$_SESSION['role']=$u['role'];

$base = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$target = !empty($redirect) ? $redirect : (($u['role']==='seller') ? 'seller-dashboard.php' : 'browse.php');
json_ok(['message'=>'Logged in','role'=>$u['role'],'redirect'=>"$base/$target"]);
?>
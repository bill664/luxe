<?php
require_once __DIR__.'/db.php'; require_once __DIR__.'/helpers.php'; session_start();
if (empty($_SESSION['user_id'])) { json_err('Login required'); }
$me = $_SESSION['user_id']; $role = $_SESSION['role'] ?? 'buyer';
$other_id = intval($_GET['other_id'] ?? 0); $product_id = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;
if(!$other_id){ json_err('Missing other_id'); }
if ($role==='seller'){ $buyer_id=$other_id; $seller_id=$me; $mark='seller_read_at'; $fromOther='buyer'; }
else { $buyer_id=$me; $seller_id=$other_id; $mark='buyer_read_at'; $fromOther='seller'; }
$params = [$buyer_id,$seller_id,$fromOther];
$sql = "UPDATE messages SET {$mark}=NOW() WHERE buyer_id=? AND seller_id=? AND sent_by=? AND {$mark} IS NULL";
if($product_id>0){ $sql .= " AND (product_id=? OR product_id IS NULL)"; $params[]=$product_id; }
$st=$pdo->prepare($sql); $st->execute($params);

$params = [$buyer_id,$seller_id];
$sql = "SELECT * FROM messages WHERE buyer_id=? AND seller_id=?";
if($product_id>0){ $sql .= " AND (product_id=? OR product_id IS NULL)"; $params[]=$product_id; }
$sql .= " ORDER BY created_at ASC";
$st=$pdo->prepare($sql); $st->execute($params); $rows=$st->fetchAll(PDO::FETCH_ASSOC);

$ty=$pdo->prepare("SELECT who, updated_at FROM typing_status WHERE buyer_id=? AND seller_id=?"); $ty->execute([$buyer_id,$seller_id]);
$typing=$ty->fetch(PDO::FETCH_ASSOC);
json_ok(['messages'=>$rows,'typing'=>$typing]);

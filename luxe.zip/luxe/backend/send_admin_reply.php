<?php
require_once __DIR__.'/db.php'; require_once __DIR__.'/helpers.php'; session_start();
if (($_SESSION['role'] ?? '')!=='admin'){ json_err('Admin only'); }
$uid=intval($_POST['user_id'] ?? 0); $msg=trim($_POST['message'] ?? '');
if(!$uid || !$msg){ json_err('Missing fields'); }
$pdo->prepare("INSERT INTO admin_messages (user_id,message,is_admin_reply) VALUES (?,?,1)")->execute([$uid,$msg]);
echo "ok";

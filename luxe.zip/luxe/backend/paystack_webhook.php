<?php
// Set this as your Paystack webhook URL
require_once __DIR__.'/config.php'; require_once __DIR__.'/db.php';
$input = @file_get_contents("php://input"); $event = json_decode($input,true);
if(!$event){ http_response_code(400); exit; }
if(($event['event'] ?? '')==='charge.success'){
  $ref = $event['data']['reference'] ?? '';
  if($ref){
    $stmt=$pdo->prepare("UPDATE seller_subscriptions SET active=1 WHERE paystack_ref=?"); $stmt->execute([$ref]);
  }
}
echo 'ok';

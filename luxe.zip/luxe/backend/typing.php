<?php
require_once __DIR__.'/db.php'; require_once __DIR__.'/helpers.php'; session_start();
if (empty($_SESSION['user_id'])) { json_err('Login required'); }
$user_id=$_SESSION['user_id']; $role=$_SESSION['role'] ?? 'buyer';
$other_id=intval($_POST['other_id'] ?? 0); if(!$other_id){ json_err('Missing other_id'); }
if ($role==='seller'){ $buyer_id=$other_id; $seller_id=$user_id; $who='seller'; }
else { $buyer_id=$user_id; $seller_id=$other_id; $who='buyer'; }
$pdo->prepare("INSERT INTO typing_status (buyer_id,seller_id,who) VALUES (?,?,?)
  ON DUPLICATE KEY UPDATE who=VALUES(who), updated_at=CURRENT_TIMESTAMP")->execute([$buyer_id,$seller_id,$who]);
echo "ok";

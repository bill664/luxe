<?php
require_once __DIR__.'/db.php'; require_once __DIR__.'/helpers.php'; session_start();
if(($_SESSION['role'] ?? '') !== 'seller'){ json_err('Seller login required'); }
$seller = $_SESSION['user_id']; $id=intval($_POST['id'] ?? 0);
$st=$pdo->prepare("SELECT image1,image2,image3,image4,image5 FROM ads WHERE id=? AND seller_id=?"); $st->execute([$id,$seller]); $ad=$st->fetch(PDO::FETCH_ASSOC);
if(!$ad){ json_err('Ad not found'); }
foreach($ad as $img){ if($img && file_exists(__DIR__.'/uploads/'.$img)) unlink(__DIR__.'/uploads/'.$img); }
$pdo->prepare("DELETE FROM ads WHERE id=? AND seller_id=?")->execute([$id,$seller]);
json_ok(['message'=>'Ad deleted']);

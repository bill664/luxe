<?php
require_once __DIR__.'/db.php'; require_once __DIR__.'/helpers.php'; session_start();
if(($_SESSION['role'] ?? '') !== 'seller'){ json_err('Seller login required'); }
$seller = $_SESSION['user_id']; $id=intval($_POST['id'] ?? 0);
$title = trim($_POST['title'] ?? ''); $desc = trim($_POST['description'] ?? ''); $price = floatval($_POST['price'] ?? 0); $cat = trim($_POST['category'] ?? '');
$st = $pdo->prepare("SELECT * FROM ads WHERE id=? AND seller_id=?"); $st->execute([$id,$seller]); $ad=$st->fetch(PDO::FETCH_ASSOC); if(!$ad){ json_err('Ad not found'); }
$imgs = [$ad['image1'],$ad['image2'],$ad['image3'],$ad['image4'],$ad['image5']];
for($i=0;$i<5;$i++){
  if(isset($_FILES['images']['name'][$i]) && $_FILES['images']['name'][$i]){
    $name = time().'_'.$i.'_'.preg_replace('/[^a-zA-Z0-9._-]/','',$_FILES['images']['name'][$i]);
    move_uploaded_file($_FILES['images']['tmp_name'][$i], __DIR__.'/uploads/'.$name);
    if($imgs[$i] && file_exists(__DIR__.'/uploads/'.$imgs[$i])) unlink(__DIR__.'/uploads/'.$imgs[$i]);
    $imgs[$i]=$name;
  }
}
$pdo->prepare("UPDATE ads SET title=?,description=?,price=?,category=?,image1=?,image2=?,image3=?,image4=?,image5=? WHERE id=? AND seller_id=?")
    ->execute([$title,$desc,$price,$cat,$imgs[0],$imgs[1],$imgs[2],$imgs[3],$imgs[4],$id,$seller]);
json_ok(['message'=>'Ad updated']);

<?php
require_once __DIR__.'/db.php'; require_once __DIR__.'/helpers.php'; session_start();
if (($_SESSION['role'] ?? '')!=='admin'){ json_err('Admin only'); }
$st=$pdo->query("SELECT u.id AS user_id, u.email, 
  SUM(CASE WHEN a.is_admin_reply=0 AND a.admin_read_at IS NULL THEN 1 ELSE 0 END) AS unread,
  MAX(a.created_at) AS last_at
  FROM admin_messages a JOIN users u ON a.user_id=u.id
  GROUP BY u.id, u.email ORDER BY last_at DESC");
$rows=$st->fetchAll(PDO::FETCH_ASSOC);
json_ok(['inbox'=>$rows]);

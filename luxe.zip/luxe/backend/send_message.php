<?php
require_once __DIR__.'/db.php'; require_once __DIR__.'/helpers.php'; session_start();
if (empty($_SESSION['user_id'])) { json_err('Login required'); }
$user_id = $_SESSION['user_id']; $role = $_SESSION['role'] ?? 'buyer';
$other_id = intval($_POST['other_id'] ?? 0); $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : null;
$text = trim($_POST['message'] ?? ''); if(!$other_id || !$text){ json_err('Missing fields'); }
if ($role==='seller'){ $buyer_id=$other_id; $seller_id=$user_id; $sent_by='seller'; }
else { $buyer_id=$user_id; $seller_id=$other_id; $sent_by='buyer'; }
$pdo->prepare("INSERT INTO messages (buyer_id,seller_id,product_id,message,sent_by) VALUES (?,?,?,?,?)")->execute([$buyer_id,$seller_id,$product_id,$text,$sent_by]);
$pdo->prepare("DELETE FROM typing_status WHERE buyer_id=? AND seller_id=?")->execute([$buyer_id,$seller_id]);
json_ok(['message'=>'sent']);

<?php
require_once __DIR__.'/db.php'; require_once __DIR__.'/helpers.php'; session_start();
if (($_SESSION['role'] ?? '')!=='admin'){ json_err('Admin only'); }
$uid=intval($_GET['user_id'] ?? 0); if(!$uid){ json_err('Missing user_id'); }
$pdo->prepare("UPDATE admin_messages SET admin_read_at=NOW() WHERE user_id=? AND is_admin_reply=0 AND admin_read_at IS NULL")->execute([$uid]);
$st=$pdo->prepare("SELECT * FROM admin_messages WHERE user_id=? ORDER BY created_at ASC"); $st->execute([$uid]);
$rows=$st->fetchAll(PDO::FETCH_ASSOC);
json_ok(['messages'=>$rows]);

<?php
require_once __DIR__.\'/db.php\'; require_once __DIR__.\'/helpers.php\'; session_start();
if (empty($_SESSION[\'user_id\']) || ($_SESSION[\'role\'] ?? \'\')!==\'seller\'){ json_err(\'Seller login required\'); }
$seller_id = $_SESSION[\'user_id\']; $product_id = intval($_GET[\'product_id\'] ?? 0);
$params = [$seller_id];
$sql = "SELECT bu.id AS buyer_id, bu.email AS buyer_email,
        SUM(CASE WHEN m.sent_by=\'buyer\' AND m.seller_read_at IS NULL THEN 1 ELSE 0 END) AS unread_count,
        MAX(m.created_at) AS last_message_at
        FROM messages m JOIN users bu ON m.buyer_id=bu.id
        WHERE m.seller_id=?";
if($product_id>0){ $sql .= " AND (m.product_id=? OR m.product_id IS NULL)"; $$params[]=$product_id }
$sql .= " GROUP BY bu.id, bu.email ORDER BY last_message_at DESC";
$st=$pdo->prepare($sql); $st->execute($params); $rows=$st->fetchAll(PDO::FETCH_ASSOC);
json_ok({\'buyers\':rows});

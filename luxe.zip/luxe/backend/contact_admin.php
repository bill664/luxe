<?php
require_once __DIR__.'/db.php'; require_once __DIR__.'/helpers.php'; session_start();
if (empty($_SESSION['user_id'])) { json_err('Login required'); }
$msg = trim($_POST['message'] ?? ''); if(!$msg){ json_err('Message required'); }
$pdo->prepare("INSERT INTO admin_messages (user_id, message, is_admin_reply) VALUES (?,?,0)")
    ->execute([$_SESSION['user_id'],$msg]);
echo "ok";

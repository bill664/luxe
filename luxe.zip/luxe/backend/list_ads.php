<?php
require_once __DIR__.'/db.php'; require_once __DIR__.'/helpers.php'; session_start();
if(empty($_SESSION['user_id'])){ json_err('Login required'); }
$selOnly = isset($_GET['mine']) ? 1 : 0;
if($selOnly && ($_SESSION['role'] ?? '')!=='seller'){ json_err('Seller login required'); }
if($selOnly){ $stmt=$pdo->prepare("SELECT * FROM ads WHERE seller_id=? ORDER BY created_at DESC"); $stmt->execute([$_SESSION['user_id']]); }
else { $stmt=$pdo->query("SELECT * FROM ads ORDER BY created_at DESC"); }
$ads=$stmt->fetchAll(PDO::FETCH_ASSOC);
json_ok(['ads'=>$ads]);

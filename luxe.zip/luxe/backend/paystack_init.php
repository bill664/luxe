<?php
require_once __DIR__.'/config.php'; require_once __DIR__.'/db.php'; session_start();
if(($_SESSION['role'] ?? '')!=='seller'){ http_response_code(403); exit('Seller login required'); }
$ref = 'LM_'.time().'_'.mt_rand(1000,9999);
$pdo->prepare("INSERT INTO seller_subscriptions (seller_id, paystack_ref, active) VALUES (?,?,0)
               ON DUPLICATE KEY UPDATE paystack_ref=VALUES(paystack_ref)")->execute([$_SESSION['user_id'],$ref]);
// Redirect the browser to Paystack checkout URL on the frontend using PAYSTACK_PUBLIC
echo json_encode(['success'=>true,'reference'=>$ref,'public_key'=>PAYSTACK_PUBLIC]);

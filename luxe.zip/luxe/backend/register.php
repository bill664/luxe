<?php
session_start();
require_once __DIR__.'/db.php';
require_once __DIR__.'/helpers.php';

$first = trim($_POST['first_name'] ?? '');
$last  = trim($_POST['last_name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$pass  = $_POST['password'] ?? '';
$confirm = $_POST['confirm_password'] ?? '';
$role  = $_POST['role'] ?? 'buyer';

if(!$first || !$last || !$email || !$pass || !$confirm){
    die('All required fields must be filled.');
}

if($pass !== $confirm){
    die('Passwords do not match.');
}

$hash = password_hash($pass, PASSWORD_BCRYPT);

$stmt = $pdo->prepare("INSERT INTO users (first_name,last_name,email,phone,password,role) VALUES (?,?,?,?,?,?)");
try {
    $stmt->execute([$first,$last,$email,$phone,$hash,$role]);
} catch (Exception $e) {
    die('Email already registered.');
}

$code = str_pad((string)random_int(0,999999), 6, '0', STR_PAD_LEFT);
$exp  = date('Y-m-d H:i:s', time()+15*60);

$pdo->prepare("UPDATE users SET otp_code=?, otp_expires=?, otp_resend_count=0, otp_last_resend=NULL, email_verified=0 WHERE email=?")
    ->execute([$code,$exp,$email]);

send_mail($email, 'Verify your email', "Your OTP is: $code");

$_SESSION['pending_email'] = $email;
$_SESSION['pending_role']  = $role;

// redirect to verify-otp in same folder
$base = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
header("Location: $base/verify-otp.php");
exit;
?>